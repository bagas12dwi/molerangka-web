<?php

use App\Http\Controllers\GalleryController;
use App\Http\Controllers\MaterialController;
use App\Http\Controllers\OverallQuizController;
use App\Http\Controllers\OverallUserScoreController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\SubMaterialController;
use App\Http\Controllers\UserScoreController;
use App\Models\UserScore;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('pages.dashboard', [
        'title' => 'Dashboard'
    ]);
});


Route::resource('materi', MaterialController::class);
Route::resource('sub-materi', SubMaterialController::class);
Route::resource('quiz-sub-materi', QuestionController::class);
Route::resource('quiz', OverallQuizController::class);
Route::resource('galeri', GalleryController::class);
Route::resource('resultQuizSubmateri', UserScoreController::class);
Route::resource('resultQuiz', OverallUserScoreController::class);


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
