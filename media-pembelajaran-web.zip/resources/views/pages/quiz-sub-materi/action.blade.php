<div class="d-flex align-middle">
    <a href="{{ url('quiz-sub-materi/' . $sub_materi->id) }}" class="btn btn-info me-2">
        <i class="bi bi-eye"></i>
    </a>
</div>
