<img src="{{ URL::asset('/storage/' . $galeri->img_path) }}" alt="Galeri" style="height: 200px; background-size: cover">
