

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Tambah <?php echo e($title); ?>

    </h5>
    <hr>
    <form action="<?php echo e(url('materi')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama Materi</label>
            <input type="text" class="form-control" name="name" id="name" aria-describedby="materiId"
                placeholder="Nama Materi" />
            <small id="materiId" class="form-text text-muted">Masukkan nama materi</small>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/materi/add.blade.php ENDPATH**/ ?>