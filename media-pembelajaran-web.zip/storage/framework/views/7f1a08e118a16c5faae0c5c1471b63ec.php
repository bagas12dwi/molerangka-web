<div class="d-flex align-middle">
    <a href="<?php echo e(url('quiz-sub-materi/' . $sub_materi->id)); ?>" class="btn btn-info me-2">
        <i class="bi bi-eye"></i>
    </a>
</div>
<?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/quiz-sub-materi/action.blade.php ENDPATH**/ ?>