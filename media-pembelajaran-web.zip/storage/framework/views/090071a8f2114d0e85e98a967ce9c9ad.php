

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Tambah <?php echo e($title); ?>

    </h5>
    <hr>
    <form action="<?php echo e(url('galeri')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="caption" class="form-label">Caption</label>
            <input type="text" class="form-control" name="caption" id="caption" placeholder="Caption" required />
        </div>
        <div class="mb-3">
            <label for="img_path" class="form-label">Pilih Gambar</label>
            <input type="file" class="form-control" name="img_path" id="img_path" placeholder="Pilih Gambar" required />
        </div>
        <a href="<?php echo e(url('galeri')); ?>" class="btn btn-warning">Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/gallery/add.blade.php ENDPATH**/ ?>