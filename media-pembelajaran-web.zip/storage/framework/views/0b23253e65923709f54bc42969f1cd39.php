

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Tambah <?php echo e($title); ?>

    </h5>
    <hr>
    <form action="<?php echo e(url('sub-materi')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="material_id" class="form-label">Materi</label>
            <select class="form-select form-select" name="material_id" id="material_id">
                <option selected>Pilih Materi</option>
                <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="name" class="form-label">Sub Materi</label>
            <input type="text" class="form-control" name="name" id="name" aria-describedby="materiId"
                placeholder="Sub Materi" />
            <small id="materiId" class="form-text text-muted">Masukkan Sub Materi</small>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Isi Materi</label>
            <input id="x" type="hidden" name="description">
            <trix-editor input="x"></trix-editor>
            
        </div>
        <div class="mb-3">
            <label for="img_path" class="form-label">Gambar</label>
            <input type="file" class="form-control" name="img_path" id="img_path" placeholder=""
                aria-describedby="gambarId" />
            <div id="gambarId" class="form-text">Jika terdapat gambar silahkan upload gambar</div>
        </div>
        <a href="<?php echo e(url('sub-materi')); ?>" class="btn btn-warning">Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/sub-materi/add.blade.php ENDPATH**/ ?>