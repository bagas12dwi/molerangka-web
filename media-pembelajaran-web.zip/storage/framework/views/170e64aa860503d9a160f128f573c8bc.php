

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Detail Sub Materi <?php echo e($sub_materi->name); ?>

    </h5>
    <hr>
    <h5 class="fw-bold">
        Nama Materi
    </h5>
    <p> <?php echo e($sub_materi->material->name); ?> </p>
    <h5 class="fw-bold">
        Nama Sub Materi
    </h5>
    <p> <?php echo e($sub_materi->name); ?> </p>
    <h5 class="fw-bold">
        Isi Materi
    </h5>
    <p> <?php echo e($sub_materi->description); ?> </p>
    <?php if($sub_materi->img_path != ''): ?>
        <h5 class="fw-bold">
            Gambar
        </h5>
        <img src="<?php echo e(URL::asset('/storage/' . $sub_materi->img_path)); ?>" class="mb-3" alt=""> <br>
    <?php endif; ?>
    <a href="<?php echo e(url('sub-materi')); ?>" class="btn btn-warning">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/sub-materi/show.blade.php ENDPATH**/ ?>