

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Edit <?php echo e($title); ?>

    </h5>
    <hr>
    <form action="<?php echo e(url('galeri/' . $galeri->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="caption" class="form-label">Caption</label>
                    <input type="text" class="form-control" name="caption" id="caption" value="<?php echo e($galeri->caption); ?>"
                        placeholder="Caption" required />
                </div>
                <input type="hidden" name="imgOld" value="<?php echo e($galeri->img_path); ?>">
                <div class="mb-3">
                    <label for="img_path" class="form-label">Pilih Gambar</label>
                    <input type="file" class="form-control" name="img_path" id="img_path" placeholder="Pilih Gambar" />
                </div>
            </div>
            <div class="col-md-6">
                <img src="<?php echo e(URL::asset('/storage/' . $galeri->img_path)); ?>" alt="Galeri"
                    style="height: 200px; background-size: cover">
            </div>
        </div>
        <a href="<?php echo e(url('galeri')); ?>" class="btn btn-warning">Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/gallery/edit.blade.php ENDPATH**/ ?>