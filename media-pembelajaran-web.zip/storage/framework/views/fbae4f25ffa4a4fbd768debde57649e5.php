

<?php $__env->startSection('konten'); ?>
    <h5 class="fw-bold">
        Edit <?php echo e($title); ?>

    </h5>
    <hr>
    <form action="<?php echo e(url('quiz-sub-materi/' . $question->id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="material_id" class="form-label">Sub Materi</label>
            <select class="form-select form-select" name="sub_material_id" id="sub_material_id" required>
                <option selected>Pilih Sub Materi</option>
                <?php $__currentLoopData = $submateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $question->sub_material_id ? 'selected' : ''); ?>>
                        <?php echo e($item->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="question_text" class="form-label">Pertanyaan</label>
            <textarea class="form-control" name="question_text" id="question_text" rows="3" required><?php echo e($question->question_text); ?></textarea>
        </div>
        <h5 class="form-label">Jawaban</h5>
        <hr>
        <?php $__currentLoopData = $question->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-3">
                <label for="<?php echo e('option_text' . $option->id); ?>" class="form-label">Jawaban</label>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="<?php echo e('is_correct' . $option->id); ?>"
                        id="flexRadioDefault1" <?php echo e($option->is_correct == true ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="flexRadioDefault1">
                        Jawaban Benar
                    </label>
                </div>
                <textarea class="form-control" name="<?php echo e('option_text' . $option->id); ?>" id="<?php echo e('option_text' . $option->id); ?>"
                    rows="2" required><?php echo e($option->option_text); ?></textarea>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('quiz-sub-materi')); ?>" class="btn btn-warning">Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\media-pembelajaran-web\resources\views/pages/quiz-sub-materi/question/edit.blade.php ENDPATH**/ ?>